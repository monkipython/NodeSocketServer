#More Examples

To see Twilio module functionality in stand-alone node applications, there are two repos you may find interesting:

* [https://github.com/kwhinnery/twilio-express](https://github.com/kwhinnery/twilio-express)
* [https://github.com/kwhinnery/twilio-raw](https://github.com/kwhinnery/twilio-raw)
