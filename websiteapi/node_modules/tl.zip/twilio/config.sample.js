//Configuration for running tests and examples against the Twilio API
module.exports = {
    accountSid:'ACXXX',
    authToken:'XXX',
    from:'+16512223333', //The Twilio number you've bought or configured
    to:'+16513334444' //The number you would like to send messages to for testing
};